# Decision Log

| Date       | Topic                   | Decision             | Owner  |
|------------|--------------------------|----------------------|--------|
| 2025-06-10 | Use Elastic v8           | ✅ Proceed            | @minh  |
| 2025-06-12 | DSL should be YAML-based | ✅ Adopt YAML syntax  | @jamie |
