# Sprint 26 Planning

## 🏃 Team Capacity
- 4 engineers @ 70% = 28 ideal days

## ✅ Committed Work
- Complete Search Rewrite Phase 2
- Begin migration of Notifications DB
- Launch internal observability dashboard v1

## 🚧 Risks
- New engineer onboarding during sprint
- Infra dependencies on analytics pipeline
