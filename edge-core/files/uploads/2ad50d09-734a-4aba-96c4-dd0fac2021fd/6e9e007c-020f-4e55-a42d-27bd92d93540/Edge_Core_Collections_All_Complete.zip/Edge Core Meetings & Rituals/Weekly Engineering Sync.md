# Weekly Engineering Sync — Template

## 📅 Date:
## 📌 Agenda:
- Team updates
- Current sprint status
- Blockers and needs
- Notable risks
- Demos (if any)

## 📋 Notes:
- [ ] Action items
- [ ] Decisions made
