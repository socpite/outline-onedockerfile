# Tech Debt Tracker

| Area            | Description                          | Owner  | Status |
|------------------|--------------------------------------|--------|--------|
| Search Router    | Needs retry logic cleanup            | @minh  | Open   |
| GraphQL Gateway  | Circular dependency w/ auth middleware | @alex  | Planned |
| Notification Job | Lacking idempotency                  | @jamie | In Progress |
