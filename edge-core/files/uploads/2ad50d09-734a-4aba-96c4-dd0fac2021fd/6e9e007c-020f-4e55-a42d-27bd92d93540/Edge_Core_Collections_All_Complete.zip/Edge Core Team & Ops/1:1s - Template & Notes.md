# 1:1s — Template

## Weekly Structure
- Wins
- Challenges
- Goals check-in
- Feedback (up/down/sideways)
- Career development

## Notes
| Date | Notes |
|------|-------|
|      |       |
