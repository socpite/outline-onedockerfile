# Onboarding Checklist

## Week 1
- [ ] GitHub access + repo cloned
- [ ] Dev env setup + test run
- [ ] Read system architecture + team charter
- [ ] Shadow 1:1 and team sync

## Week 2
- [ ] First small PR merged
- [ ] Pair on sprint task
- [ ] Attend design crit
