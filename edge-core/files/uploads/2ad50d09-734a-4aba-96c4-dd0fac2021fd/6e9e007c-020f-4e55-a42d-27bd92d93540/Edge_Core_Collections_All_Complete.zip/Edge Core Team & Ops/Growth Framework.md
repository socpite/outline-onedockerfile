# Growth Framework

## IC1 → IC2
- Contributes independently to scoped tasks
- Responds well to feedback and code reviews

## IC2 → IC3
- Owns small features end-to-end
- Helps unblock others
- Participates in planning

## IC3 → IC4
- Leads cross-team projects
- Mentors junior engineers
- Sets direction in domain
