# Hiring Rubric

## Areas

### System Design (30%)
- Can break down complex systems into components
- Understands trade-offs

### Execution (30%)
- Writes clean, maintainable code
- Debugs effectively

### Collaboration (20%)
- Communicates clearly
- Gives and receives feedback

### Product Judgment (20%)
- Understands user value
- Prioritizes effectively
