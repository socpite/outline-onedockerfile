# Tech Debt Tracker

| Area | Description | Owner | Status |
|------|-------------|--------|--------|
| Search Router | Needs retry logic cleanup | @minh | Open |
...
