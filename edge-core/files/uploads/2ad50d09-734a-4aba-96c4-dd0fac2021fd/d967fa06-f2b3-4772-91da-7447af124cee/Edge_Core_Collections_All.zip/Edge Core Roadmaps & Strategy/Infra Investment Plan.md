# Infra Investment Plan — 2025

## Goals
- Increase reliability of real-time systems
- Expand observability coverage
...
