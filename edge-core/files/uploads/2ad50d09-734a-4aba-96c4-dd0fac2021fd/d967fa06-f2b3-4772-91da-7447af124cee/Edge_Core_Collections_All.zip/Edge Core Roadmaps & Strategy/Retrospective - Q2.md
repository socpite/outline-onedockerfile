# Retrospective — Q2 2025

## Highlights
- Notifications platform launched
- On-call burden down 20%
...
