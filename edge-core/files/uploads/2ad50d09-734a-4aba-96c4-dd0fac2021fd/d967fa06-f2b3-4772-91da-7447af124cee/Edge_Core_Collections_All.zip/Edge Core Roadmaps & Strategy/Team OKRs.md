# Team OKRs — Q3 2025

## Objective 1: Make Search Fast and Reliable
- KR1: < 100ms median latency
- KR2: 99.99% success rate on key endpoints
...
