# Design Crit — Notifications Platform

## Overview
- Goal: Improve hierarchy and responsiveness of notifications

## Designs Reviewed
...
