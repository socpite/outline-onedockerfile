# Weekly Engineering Sync — Template

## 📅 Date:
## 📌 Agenda:
- Updates by team
- Risks/blockers
- Decisions
...
