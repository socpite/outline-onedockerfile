# Decision Log

| Date | Topic | Decision | Owner |
|------|-------|----------|-------|
| 2025-06-10 | Use Elastic v8 | ✅ Proceed | @minh |
...
