# 1:1s — Template

## Structure
- Wins
- Challenges
- Growth
- Feedback
...
