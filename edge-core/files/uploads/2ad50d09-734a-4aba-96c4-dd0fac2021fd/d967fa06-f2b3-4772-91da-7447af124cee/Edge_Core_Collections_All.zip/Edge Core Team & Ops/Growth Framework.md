# Growth Framework

## IC1 → IC2
- Contributes independently to scoped tasks
- Seeks feedback and implements improvements
...
