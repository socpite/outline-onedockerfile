# Hiring Rubric

## Engineering Interviews
- System Design (30%)
- Execution/Code Quality (30%)
- Collaboration (20%)
- Judgment (20%)
...
