# Edge Core — Team Charter

## Mission
Build and maintain core systems that power search and discovery...

## Scope
- Search Infra
- Notifications Backend
...
