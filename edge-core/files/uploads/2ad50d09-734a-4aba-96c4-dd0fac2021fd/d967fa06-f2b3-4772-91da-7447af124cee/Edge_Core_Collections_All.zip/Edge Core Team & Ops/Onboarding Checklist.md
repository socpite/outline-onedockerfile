# Onboarding Checklist

✅ GitHub access  
✅ Setup dev environment  
✅ Read key docs  
✅ Shadow code review  
...
